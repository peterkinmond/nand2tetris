C_ARITHMETIC = 'C_ARITHMETIC'
# TODO: add all arithmetic/logic commands
C_PUSH = 'C_PUSH'
C_POP = 'C_POP'

